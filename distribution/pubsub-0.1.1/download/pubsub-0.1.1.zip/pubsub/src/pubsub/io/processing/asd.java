package pubsub.io.processing;

import java.io.InputStream;

public class asd {

	byte[] buffer;
	int bytes;
	private InputStream mmInStream;
	private byte[] storedbuffer;
	private byte[] readbuffer;

	public void test() {

		try {
			
			buffer = new byte[1024];

			// Read from the InputStream
			bytes = mmInStream.read(buffer);

			if (bytes < 9 && storedbuffer == null) {
				/*
				 * if bytes is less than 9... just copy the buffer and attach it before
				 * the next buffer
				 */
				storedbuffer = new byte[bytes];

				for (int i = 0; i < storedbuffer.length; i++)
					storedbuffer[i] = buffer[i];

			} else if (storedbuffer != null) {
				/* If we have something in "storedbuffer" use it! */
				readbuffer = new byte[bytes + storedbuffer.length];
				int index = 0;

				for (int i = 0; i < storedbuffer.length; i++, index++)
					readbuffer[index] = storedbuffer[i];
				for (int j = 0; j < bytes; j++, index++)
					readbuffer[index] = buffer[j];

			} else if (bytes >= 9) {
				readbuffer = new byte[bytes];
				for (int i = 0; i < bytes; i++)
					readbuffer[i] = buffer[i];
			}

			/* Do parsing on readbuffer */
			if (readbuffer != null && readbuffer.length >= 9) {
				if (readbuffer != null) {
					/* Parse the buffer */
					try {
						parseReadBuffer(readbuffer, readbuffer.length);
					} catch (Exception e) {

					}
					/* And after parsing the buffer/s, kill them */
					readbuffer = null;
					storedbuffer = null;
					buffer = null;
				}
			}

		} catch (Exception e) {
		}
	}

	private void parseReadBuffer(byte[] readbuffer2, int length) {
		// TODO Auto-generated method stub

	}
}